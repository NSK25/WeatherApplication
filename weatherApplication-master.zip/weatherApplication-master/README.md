This is web application where we can search weather conditons of a particular city like Temparature, Humidity and pressure over next five days
